<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DELETE PRODUCT</title>
</head>
<body>
    <fieldset>
        <legend>DELETE PRODUCT</legend>
        <form action="../controller/deletecon.php" method="post">
            <br> Name: 
            <br> Buying Price:
            <br> Selling Price:
            <br> Displayable:
            <br> <hr>
            <input type="submit" value="Delete">
        </form>
    </fieldset>
</body>
</html>