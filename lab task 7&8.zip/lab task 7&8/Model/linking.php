<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Pangolin&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/4e32f7f314.js" crossorigin="anonymous"></script>