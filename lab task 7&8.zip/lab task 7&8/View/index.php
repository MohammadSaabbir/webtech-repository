<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Public Home</title>
    <style>
    .ind h1 {
        background-color: brown;
        font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans';
        font-size: 50px;
        margin-top: 12.3rem;
        text-align: center;
        padding: 1rem;
        margin-bottom: 20%;
    }

    .ind {
        color: whitesmoke;
    }

    body {
        background-color: RGBA(124, 145, 145, 60%);
        height: auto;

    }
    </style>
    <?php include './common/header.php';
?>
</head>

<body>

    <div class="ind">
        <h1>Welcome to surjo LTD</h1>
    </div>

</body>
<?php
include './common/footer.php';
?>

</html>